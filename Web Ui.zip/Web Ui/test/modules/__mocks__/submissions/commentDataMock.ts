import { CommentsCreationObject } from "../../../../src/modules/teacherCommentsOnSubmissions/domain/CommentsInterface";

export const commentDataMock: CommentsCreationObject = {
    submission_id: 129,
    teacher_id: 10,
    content: "Buen trabajo",
};