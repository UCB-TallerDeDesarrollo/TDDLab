export const cookieUserData =
{
    "uid": "kjasdf98asdhf9",
    "email": "usuario@example.com",
    "emailVerified": true,
    "displayName": "Usuario de Prueba",
    "isAnonymous": false,
    "photoURL": "https://example.com/profile.jpg",
    "providerData": [
      {
        "providerId": "github.com",
        "uid": "123456",
        "displayName": "Usuario de Prueba",
        "email": "usuario@example.com",
        "phoneNumber": null,
        "photoURL": "https://example.com/profile.jpg"
      }
    ],
    "stsTokenManager": {
      "refreshToken": "aslkdfjhasd8fhasd9hfasdofh8",
      "accessToken": "eyJhbGciOiJSUzI1NiIsImtpZCI6ImE2YzYzNTFmMmEzZWMxMjg2NTA1MzBkMTVmNmM0Y2Y0NTcxYTQ1NTciLCJ0eXAiOiJKV1QifQ.eyJuYW1lIjoiVXN1YXJpbyBkZSBQcnVlYmEiLCJwaWN0dXJlIjoiaHR0cHM6Ly9leGFtcGxlLmNvbS9wcm9maWxlLmpwZyIsImVtYWlsIjoiY29udGFjdEBleGFtcGxlLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjpmYWxzZSwiaXNzIjoiaHR0cHM6Ly9nb29nbGUuY29tL3RkZGxhYi1ob3N0aW5nLWZpcmViYXNlIiwiYXVkIjoidGRkbGFiLWhvc3RpbmctZmlyZWJhc2UiLCJhdXRoX3RpbWUiOjE3MDA0MzA4MDIsInVzZXJfaWQiOiJrSmFzZGY5OGFzZGhmOSIsInN1YiI6ImtKYXNkZjk4YXNkaGY5IiwiaWF0IjoxNzAwNDMwODAyLCJleHAiOjE3MDA0MzQ0MDIsImVtYWlsIjoibnVsbGFzc2FjcmlAZXhhbXBsZS5jb20iLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsImZpcmViYXNlIjp7ImlkZW50aXRpZXMiOnsiZ2l0aHViLmNvbSI6WyI4OTgyMzU2NCJdLCJlbWFpbCI6WyJudWxsYXNzYWNyaUBleGFtcGxlLmNvbSJdfSwic2lnbl9pbl9wcm92aWRlciI6ImdpdGh1Yi5jb20ifX0.AMf-vBxSqsTmZhFBYLgoIqRxM2_sMCNWiR0P3Lga-wz1j2fVJFZ9kkdQVAfcsU40Mg3L2MOJ0mub4UAWuEL8zpfPWyqjFJTOABo8ShaN9H08fwnXrv1K0qLg2rUmxVURI8-SccVmr9P5ZX955C8_rg8wEBzwMs0_YzGds9VQvQ7nkV3TjpmGL9fs485dPxGHWFvph_jTOvOMMf5TvrOfqIXadkPBydZbaiHaNAst4UBBWeFybaco4yEY2PIb4e3YXmKZ_VUWm92_vT-2i32XUzTc75Pex3fX-YVCdriEcqMr7K-R8XNPv0HN1ta7IijdqqcoiHR56cF9ANKtMuIZqnbZSmjPa2e-_5dwMm5ZN9mCbXEkFDS4HteqMFur7nDoUIew6ew_AvwY",
      "expirationTime": 1700434402652
    },
    "createdAt": "1699331020761",
    "lastLoginAt": "1700430802520",
    "appName": "[DEFAULT]"
  }
  