export interface CommitCycle{
    url: string;
    sha : string;
    tddCylce: string;
}