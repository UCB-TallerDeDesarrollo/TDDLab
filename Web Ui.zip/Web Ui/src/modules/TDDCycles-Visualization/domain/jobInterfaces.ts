export interface JobDataObject {
  sha: string;
  conclusion: string;
}
