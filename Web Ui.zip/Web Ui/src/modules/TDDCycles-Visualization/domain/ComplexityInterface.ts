export interface ComplexityObject{
    ciclomaticComplexity: number;
    file?:string;
    functionName:string;
    avgComplexity:number;
    color:string;
    commit:number
}