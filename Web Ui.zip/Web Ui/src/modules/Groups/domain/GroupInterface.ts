export interface GroupDataObject {
  id: number;
  groupName: string;
  groupDetail: string;
  creationDate: Date;
}
