export interface UserOnDb {
  id?: number;
  email: string;
  groupid: number;
  role: string;
}
