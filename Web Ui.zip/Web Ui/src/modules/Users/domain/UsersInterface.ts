export interface UserDataObject {
    id: number;
    email: string;
    groupid: number;
    role: string;
  }